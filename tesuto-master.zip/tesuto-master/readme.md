### Các chức năng cần cung cấp:
- Chế độ luyện tập: Trong chế độ này, người dùng làm các bài thi luyện tập với số lượng câu hỏi và thời gian làm bài nhất định. Sau khi hoàn thành bài thi, ứng dụng thông báo số câu trả lời đúng
- Chế độ thi:
    - Người dùng có thể tạo phòng thi mới, thiết lập số câu hỏi và thời gian thi cho phòng thi. Người dùng có thể quyết định bắt đầu thi ở thời điểm bất kỳ cho phòng thi
    - Xem danh sách các phòng thi và trạng thái của mỗi phòng (chưa bắt đầu, đang diễn ra, đã kết thúc).
    - Tham gia vào một phòng thi khi phòng thi chưa bắt đầu
    - Xem kết quả thi của các phòng thi đã kết thúc
    - Khi bắt đầu thi, server sẽ gửi lại cho người dùng đề thi bao gồm các câu hỏi thi.
    - Người dùng có thể nộp bài sớm trước khi thời gian thi kết thúc.
    - Sau khi hết giờ thi, server thông báo số câu trả lời đúng cho người thi tương ứng.